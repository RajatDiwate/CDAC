package com.cdac.Login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet({"*.do"})
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 String jspname=null;
     RequestDispatcher dispatcher =null;
       public Registration() {
       super();
    }
       private String mymsg;
       
       
       public void init() throws ServletException {
    	      mymsg = "Hello World!";
    	   }

       
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			  // Setting up the content type of webpage
	      response.setContentType("text/html");
//		     
		     
//		      String dispatch;
		      String command =(request.getServletPath());
		       System.out.println("calling"+command);
		       switch(command) {
		       case "/Login.do":
		           {
		    	   String uname=request.getParameter("username");
		    	   System.out.println(uname);
		    	   String password=request.getParameter("password");
		    	   if(uname.equals("rajat") && password.equals("rajat")) {
		    		   
		    		   jspname ="/Welcome.jsp";
		    	       }
		    	   else {
		    		   jspname="/Error.jsp";
		    	   }
		    	   break;
		           }
		       default :{
		    	   jspname="/index.html"; 
		    	   break;
		       }
		       
		       
		       }
		       
		      dispatcher = request.getRequestDispatcher(jspname);
		       dispatcher.forward(request, response); 
		      // Writing message to the web page
//		      PrintWriter out = response.getWriter();
//		      out.println("<h1>" + mymsg + "</h1>");
			
	}
//		   public void doGet(HttpServletRequest request, 
//				      HttpServletResponse response)
//				      throws ServletException, IOException 
//				   {
//
//				      // Setting up the content type of webpage
//				      response.setContentType("text/html");
//
//				      // Writing message to the web page
//				      PrintWriter out = response.getWriter();
//				      out.println("<h1>" + mymsg + "</h1>");
//				   }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
//	 public void destroy() {
//	      /* leaving empty for now this can be
//	       * used when we want to do something at the end
//	       * of Servlet life cycle
//	       */
//	   }
}
